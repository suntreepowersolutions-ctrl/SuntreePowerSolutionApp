HOW TO GET THE APK (no Android Studio needed)
1. Create a free account at github.com and press New repository (name: suntree-desk, Private is fine).
2. Press "uploading an existing file", drag in EVERYTHING from this folder
   (www folder, .github folder, package.json, capacitor.config.json, .gitignore).
   Note: the .github folder must be uploaded too. Commit.
3. Open the Actions tab -> "Build APK" -> Run workflow (it also starts by itself after upload).
4. After about 5-8 minutes open the finished run and download "suntree-desk-apk" (zip) at the bottom.
5. Unzip, send app-debug.apk to your phone, tap it, allow "Install unknown apps", Install.
